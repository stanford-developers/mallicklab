<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" dir="ltr">
	<head>
	<!-- viewport fix for devices -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	
	<!-- load core head -->
	<base href="https://mallicklab.stanford.edu/index.php" />
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Systems Biology, Proteomics, Cancer Biology, Bioinformatics, Biomarkers, Multi-scale Modeling, Complexity, Proteome Informatics, ProteoWizard, ProteoTypic Peptides, Canary Center, Early Cancer Detection, Parag Mallick" />
	<meta name="robots" content="index, follow" />
	<meta name="description" content="Official Website of the Mallick Lab at Stanford University.  Studies of Systems Biology, Proteomics, Cancer Biology, Bioinformatics, Biomarkers, Multi-scale Modeling, Complexity. Translating multi-omic discovery into precision diagnostics." />
	<meta name="generator" content="Joomla! - Open Source Content Management" />
	<title>Mallick Lab  - home</title>
	<link href="/?format=feed&amp;type=rss" rel="alternate" type="application/rss+xml" title="RSS 2.0" />
	<link href="/?format=feed&amp;type=atom" rel="alternate" type="application/atom+xml" title="Atom 1.0" />
	<link href="/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
	<link href="/media/system/css/modal.css?812fcc30e103faf7dfd952dbf8702b35" rel="stylesheet" type="text/css" />
	<link href="https://mallicklab.stanford.edu/templates/jm-exclusive-furniture/css/bootstrap.css" rel="stylesheet" type="text/css" />
	<link href="https://mallicklab.stanford.edu/templates/jm-exclusive-furniture/css/bootstrap_responsive.css" rel="stylesheet" type="text/css" />
	<link href="https://mallicklab.stanford.edu/templates/jm-exclusive-furniture/css/extensions.css" rel="stylesheet" type="text/css" />
	<link href="https://mallicklab.stanford.edu/templates/jm-exclusive-furniture/css/template.css" rel="stylesheet" type="text/css" />
	<link href="https://mallicklab.stanford.edu/templates/jm-exclusive-furniture/css/template_responsive.css" rel="stylesheet" type="text/css" />
	<link href="https://mallicklab.stanford.edu/templates/jm-exclusive-furniture/css/style1.css" rel="stylesheet" type="text/css" />
	<link href="https://mallicklab.stanford.edu/templates/jm-exclusive-furniture/css/animated-buttons.css" rel="stylesheet" type="text/css" />
	<link href="https://mallicklab.stanford.edu/templates/jm-exclusive-furniture/css/custom.css" rel="stylesheet" type="text/css" />
	<link href="http://fonts.googleapis.com/css?family=Lato:400,300" rel="stylesheet" type="text/css" />
	<link href="https://mallicklab.stanford.edu/templates/jm-exclusive-furniture/cache/custom_css_0fdc36c413c66f3ae80170d0f91c9a62.css" rel="stylesheet" type="text/css" />
	<link href="/media/djmediatools/css/tabber_2ee7ca899ab06e6d90a731f0e70d9b72.css" rel="stylesheet" type="text/css" />
	<link href="/templates/jm-exclusive-furniture/css/djmenu.css" rel="stylesheet" type="text/css" />
	<link href="/templates/jm-exclusive-furniture/css/djmenu_fx.css" rel="stylesheet" type="text/css" />
	<style type="text/css">
.dj-select {display: none;margin:10px;padding:5px;font-size:1.5em;max-width:95%;height:auto;}
		@media (max-width: 800px) {
  			#dj-main90.allowHide { display: none; }
  			#dj-main90select { display: inline-block; }
		}
	
	</style>
	<script type="application/json" class="joomla-script-options new">{"csrf.token":"b4a1f2c57bbb2fc49eeddb0858fb603f","system.paths":{"root":"","base":""}}</script>
	<script src="/media/jui/js/jquery.min.js?812fcc30e103faf7dfd952dbf8702b35" type="text/javascript"></script>
	<script src="/media/jui/js/jquery-noconflict.js?812fcc30e103faf7dfd952dbf8702b35" type="text/javascript"></script>
	<script src="/media/jui/js/jquery-migrate.min.js?812fcc30e103faf7dfd952dbf8702b35" type="text/javascript"></script>
	<script src="/media/system/js/caption.js?812fcc30e103faf7dfd952dbf8702b35" type="text/javascript"></script>
	<script src="/media/system/js/mootools-core.js?812fcc30e103faf7dfd952dbf8702b35" type="text/javascript"></script>
	<script src="/media/system/js/core.js?812fcc30e103faf7dfd952dbf8702b35" type="text/javascript"></script>
	<script src="/media/system/js/mootools-more.js?812fcc30e103faf7dfd952dbf8702b35" type="text/javascript"></script>
	<script src="/media/system/js/modal.js?812fcc30e103faf7dfd952dbf8702b35" type="text/javascript"></script>
	<script src="/media/jui/js/bootstrap.min.js?812fcc30e103faf7dfd952dbf8702b35" type="text/javascript"></script>
	<script src="https://mallicklab.stanford.edu/templates/jm-exclusive-furniture/js/styleswitcher.js" type="text/javascript"></script>
	<script src="https://mallicklab.stanford.edu/templates/jm-exclusive-furniture/js/scripts.js" type="text/javascript"></script>
	<script src="/components/com_djmediatools/assets/js/powertools-1.2.0.js" type="text/javascript"></script>
	<script src="/components/com_djmediatools/layouts/slideshow/js/slideshow.js" type="text/javascript"></script>
	<script src="/components/com_djmediatools/layouts/tabber/js/tabber.js" type="text/javascript"></script>
	<script src="/modules/mod_djmenu/assets/js/dropline-helper.js" type="text/javascript"></script>
	<script src="/modules/mod_djmenu/assets/js/djselect.js" type="text/javascript"></script>
	<script src="/modules/mod_djmenu/assets/js/djmenu.js" type="text/javascript"></script>
	<script type="text/javascript">
jQuery(window).on('load',  function() {
				new JCaption('img.caption');
			});jQuery(function($) {
			SqueezeBox.initialize({});
			SqueezeBox.assign($('a.modal').get(), {
				parse: 'rel'
			});
		});

		window.jModalClose = function () {
			SqueezeBox.close();
		};
		
		// Add extra modal close functionality for tinyMCE-based editors
		document.onreadystatechange = function () {
			if (document.readyState == 'interactive' && typeof tinyMCE != 'undefined' && tinyMCE)
			{
				if (typeof window.jModalClose_no_tinyMCE === 'undefined')
				{	
					window.jModalClose_no_tinyMCE = typeof(jModalClose) == 'function'  ?  jModalClose  :  false;
					
					jModalClose = function () {
						if (window.jModalClose_no_tinyMCE) window.jModalClose_no_tinyMCE.apply(this, arguments);
						tinyMCE.activeEditor.windowManager.close();
					};
				}
		
				if (typeof window.SqueezeBoxClose_no_tinyMCE === 'undefined')
				{
					if (typeof(SqueezeBox) == 'undefined')  SqueezeBox = {};
					window.SqueezeBoxClose_no_tinyMCE = typeof(SqueezeBox.close) == 'function'  ?  SqueezeBox.close  :  false;
		
					SqueezeBox.close = function () {
						if (window.SqueezeBoxClose_no_tinyMCE)  window.SqueezeBoxClose_no_tinyMCE.apply(this, arguments);
						tinyMCE.activeEditor.windowManager.close();
					};
				}
			}
		};
		jQuery(function($) {
			 $('.hasTip').each(function() {
				var title = $(this).attr('title');
				if (title) {
					var parts = title.split('::', 2);
					var mtelement = document.id(this);
					mtelement.store('tip:title', parts[0]);
					mtelement.store('tip:text', parts[1]);
				}
			});
			var JTooltips = new Tips($('.hasTip').get(), {"maxTitleChars": 50,"fixed": false});
		});window.addEvent('domready',function(){ if(!this.DJSlideshow5m98) this.DJSlideshow5m98 = new DJImageTabber('dj-tabber5m98',{autoplay: 1,pause_autoplay: 1,transition: Fx.Transitions.Expo.easeInOut,duration: 3000,delay: 9000,slider_type: 'fade',desc_effect: 'fade',width: 700,height: 350,spacing: 1,navi_margin: 51,preload: 0,tab_height: 80,tab_indicator: 2}) });window.addEvent('domready',function(){document.id('dj-main90').addClass('allowHide')});window.addEvent('domready',function(){ this.djmenu90 = new DJMenus(document.id('dj-main90'), {wrapper: document.id('jm-djmenu'), transition: 'cubic:out', duration: 200, delay: 1200,
		height_fx: true, width_fx: true, opacity_fx: true,
		height_fx_sub: true, width_fx_sub: true, opacity_fx_sub: true }); });
	</script>

	
		 

	<!--[if lt IE 9]>
	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js" type="text/javascript"></script>
	<script src="https://mallicklab.stanford.edu/templates/jm-exclusive-furniture/js/respond.src.js" type="text/javascript"></script>
	<link href="https://mallicklab.stanford.edu/templates/jm-exclusive-furniture/css/ie8.css" rel="stylesheet" type="text/css" />
	<![endif]-->
	<!--[if IE 9]>
	<link href="https://mallicklab.stanford.edu/templates/jm-exclusive-furniture/css/ie9.css" rel="stylesheet" type="text/css" />
	<![endif]-->
	
	<!-- template path for styleswitcher script -->
	<script type="text/javascript">
		$template_path = 'https://mallicklab.stanford.edu/templates/jm-exclusive-furniture';
	</script>
	
			<link href="https://mallicklab.stanford.edu/images/favicon.ico" rel="Shortcut Icon" />
		
		
	
		<script type="text/javascript">
	  var _gaq = _gaq || [];
	  _gaq.push(['_setAccount', '   (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r']);
	  _gaq.push(['_trackPageview']);
	
	  (function() {
		var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	  })();
	</script>
	</head>	<body>
		<div id="jm-allpage">
			
<section id="jm-bar">
	<div id="jm-bar-in">	
		<div class="container-fluid">
        	            <div id="jm-logo-sitedesc" class="pull-left">
                                <h1 id="jm-logo">
                	<a href="https://mallicklab.stanford.edu/" onfocus="blur()" >
                		                		<img src="https://mallicklab.stanford.edu/images/modules/logo.png" alt="Mallick Lab" border="0" />
                		                	</a>
                </h1>
                                                <div id="jm-sitedesc">
                	~ translating multi-omic discovery into precision diagnostics ~                </div>
                            </div>
                 
						<nav id="jm-djmenu" class="pull-right">
				<ul id="dj-main90" class="dj-main"><li class="dj-up itemid474 first active"><a href="/" class="dj-up_a active" ><span >home</span></a></li>
<li class="dj-up itemid517"><a href="/peeps" class="dj-up_a" ><span >peeps</span></a></li>
<li class="dj-up itemid476"><a href="/research" class="dj-up_a" ><span >research</span></a></li>
<li class="dj-up itemid511"><a href="/faq" class="dj-up_a" ><span >faq</span></a></li>
<li class="dj-up itemid515"><a href="/pubs" class="dj-up_a" ><span >pubs</span></a></li>
<li class="dj-up itemid535"><a href="/resources" class="dj-up_a" ><span >resources</span></a></li>
<li class="dj-up itemid551 last"><a href="/funding" class="dj-up_a" ><span >funding</span></a></li>
</ul>
			</nav>
					</div>
	</div>	
</section>
	
			
<header id="jm-header">
	<div class="container-fluid">
		<div id="jm-header-in" class="shadow">
			<div id="jm-header-in-shadowbottom" class="shadowbottom">
					<div class="jm-module slider-ms">
		<div  class="jm-module-in">
					    <div class="jm-module-content clearfix">
		    	
<div style="border: 0px !important;">
<div id="dj-tabber5m98" class="dj-tabber">
	<div class="dj-tabber-in dj-tabs-right">
		<div class="dj-slides">
        	
          				
				<div class="dj-slide">
					<div class="dj-slide-in">
						            										<img src="/" title="/media/djmediatools/cache/5-front/700x350-crop-90-meaningful_ai.png" alt="meaningful AI" class="dj-image" />												
											</div>
				</div>
				
								<div class="dj-slide-desc">
														<!-- Slide description area: START -->
					<div class="dj-slide-desc-in">	
						<div class="dj-slide-desc-bg"></div>
						<div class="dj-slide-desc-text">
														
															<div class="dj-slide-title">
																			meaningful AI																	</div>
														
															<div class="dj-slide-description">
																	<p>building new approaches to AI that require less input data and generate more accurate explanations</p>																</div>
														
														<div style="clear: both"></div>
						</div>
					</div>
					<!-- Slide description area: END -->
								</div>
								
            			
				<div class="dj-slide">
					<div class="dj-slide-in">
						            										<img src="/" title="/media/djmediatools/cache/images/figs/banners/700x350-crop-90-futzedpixels.png" alt="integrated omics" class="dj-image" />												
											</div>
				</div>
				
								<div class="dj-slide-desc">
														<!-- Slide description area: START -->
					<div class="dj-slide-desc-in">	
						<div class="dj-slide-desc-bg"></div>
						<div class="dj-slide-desc-text">
														
															<div class="dj-slide-title">
									<a href="/research" target="_self">										integrated omics									</a>								</div>
														
															<div class="dj-slide-description">
																	<p>approaches to rationally integrate diverse types of high-throughput data.</p>																</div>
														
														<div style="clear: both"></div>
						</div>
					</div>
					<!-- Slide description area: END -->
								</div>
								
            			
				<div class="dj-slide">
					<div class="dj-slide-in">
						            										<img src="/" title="/media/djmediatools/cache/images/figs/banners/700x350-crop-90-networkyness_compressed.jpg" alt="multi-scale models" class="dj-image" />												
											</div>
				</div>
				
								<div class="dj-slide-desc">
														<!-- Slide description area: START -->
					<div class="dj-slide-desc-in">	
						<div class="dj-slide-desc-bg"></div>
						<div class="dj-slide-desc-text">
														
															<div class="dj-slide-title">
									<a href="/research" target="_self">										multi-scale models									</a>								</div>
														
															<div class="dj-slide-description">
																	<p>modeling the non-linear, multi-scale processes that govern how cells behave and misbehave.</p>																</div>
														
														<div style="clear: both"></div>
						</div>
					</div>
					<!-- Slide description area: END -->
								</div>
								
            			
				<div class="dj-slide">
					<div class="dj-slide-in">
						            										<img src="/" title="/media/djmediatools/cache/images/figs/banners/700x350-crop-90-bloodsamples_compressed.jpg" alt="biomarker discovery" class="dj-image" />												
											</div>
				</div>
				
								<div class="dj-slide-desc">
														<!-- Slide description area: START -->
					<div class="dj-slide-desc-in">	
						<div class="dj-slide-desc-bg"></div>
						<div class="dj-slide-desc-text">
														
															<div class="dj-slide-title">
									<a href="/research" target="_self">										biomarker discovery									</a>								</div>
														
															<div class="dj-slide-description">
																	<p>understanding the processes that give rise to biomarkers and govern their potential utility.</p>																</div>
														
														<div style="clear: both"></div>
						</div>
					</div>
					<!-- Slide description area: END -->
								</div>
								
            			
				<div class="dj-slide">
					<div class="dj-slide-in">
						            										<img src="/" title="/media/djmediatools/cache/images/figs/banners/700x350-crop-90-flippedandstuff_compressed.jpg" alt="tumor evolution" class="dj-image" />												
											</div>
				</div>
				
								<div class="dj-slide-desc">
														<!-- Slide description area: START -->
					<div class="dj-slide-desc-in">	
						<div class="dj-slide-desc-bg"></div>
						<div class="dj-slide-desc-text">
														
															<div class="dj-slide-title">
									<a href="/research" target="_self">										tumor evolution									</a>								</div>
														
															<div class="dj-slide-description">
																	<p>characterizing how evolutionary forces (e.g. microenvironment, or drug treatment) impact tumor composition.</p>																</div>
														
														<div style="clear: both"></div>
						</div>
					</div>
					<!-- Slide description area: END -->
								</div>
								
            			
				<div class="dj-slide">
					<div class="dj-slide-in">
						            										<img src="/" title="/media/djmediatools/cache/images/figs/700x350-crop-90-psuedo2d_gel.jpg" alt="proteomics technology" class="dj-image" />												
											</div>
				</div>
				
								<div class="dj-slide-desc">
														<!-- Slide description area: START -->
					<div class="dj-slide-desc-in">	
						<div class="dj-slide-desc-bg"></div>
						<div class="dj-slide-desc-text">
														
															<div class="dj-slide-title">
									<a href="/research" target="_self">										proteomics technology									</a>								</div>
														
															<div class="dj-slide-description">
																	<p>experimental and computational approaches to improve the throughput and sensitivity of proteomics technologies</p>																</div>
														
														<div style="clear: both"></div>
						</div>
					</div>
					<!-- Slide description area: END -->
								</div>
								
            			
				<div class="dj-slide">
					<div class="dj-slide-in">
						            										<img src="/" title="/media/djmediatools/cache/images/figs/banners/700x350-crop-90-proteowizard_psdeps_onpurple_compressed.jpg" alt="proteoWizard" class="dj-image" />												
											</div>
				</div>
				
								<div class="dj-slide-desc">
														<!-- Slide description area: START -->
					<div class="dj-slide-desc-in">	
						<div class="dj-slide-desc-bg"></div>
						<div class="dj-slide-desc-text">
														
															<div class="dj-slide-title">
									<a href="/research" target="_self">										proteoWizard									</a>								</div>
														
															<div class="dj-slide-description">
																	<p>a platform to accelerate the development of proteomics analysis tools.</p>																</div>
														
														<div style="clear: both"></div>
						</div>
					</div>
					<!-- Slide description area: END -->
								</div>
								
                    	
        </div>
        <div class="dj-navigation">
        	<div class="dj-navigation-in">
        			        		<img class="dj-prev " src="/images/modules/slider/prev.png" alt="Previous" />
					<img class="dj-next " src="/images/modules/slider/next.png" alt="Next" />
													<img class="dj-play " src="/images/modules/slider/play.png" alt="Play" />
					<img class="dj-pause " src="/images/modules/slider/pause.png" alt="Pause" />
        					</div>
		</div>
		<div class="dj-tabs">
			<div class="dj-tabs-in">
								<div class="dj-tab dj-tab-active">
					<span class="dj-tab-in">						
						
						<!--[if lte IE 7]>
						<table cellpadding="0" cellspacing="0" border="0"><tr>
													<td>
							<img src="/media/djmediatools/cache/5-front/70x40-crop-80-meaningful_ai.png" alt="meaningful AI" width="70" height="40" />
							</td>
												<td width="100%">
						meaningful AI						</td>
						</tr></table>
						<![endif]-->
						
						<span>
							<img src="/media/djmediatools/cache/5-front/70x40-crop-80-meaningful_ai.png" alt="meaningful AI" width="70" height="40" />
						</span>						<span>
						meaningful AI						</span>
						
					</span>
				</div>
								<div class="dj-tab ">
					<span class="dj-tab-in">						
						
						<!--[if lte IE 7]>
						<table cellpadding="0" cellspacing="0" border="0"><tr>
													<td>
							<img src="/media/djmediatools/cache/images/figs/banners/70x40-crop-80-futzedpixels.png" alt="integrated omics" width="70" height="40" />
							</td>
												<td width="100%">
						integrated omics						</td>
						</tr></table>
						<![endif]-->
						
						<span>
							<img src="/media/djmediatools/cache/images/figs/banners/70x40-crop-80-futzedpixels.png" alt="integrated omics" width="70" height="40" />
						</span>						<span>
						integrated omics						</span>
						
					</span>
				</div>
								<div class="dj-tab ">
					<span class="dj-tab-in">						
						
						<!--[if lte IE 7]>
						<table cellpadding="0" cellspacing="0" border="0"><tr>
													<td>
							<img src="/media/djmediatools/cache/images/figs/banners/70x40-crop-80-networkyness_compressed.jpg" alt="multi-scale models" width="70" height="40" />
							</td>
												<td width="100%">
						multi-scale models						</td>
						</tr></table>
						<![endif]-->
						
						<span>
							<img src="/media/djmediatools/cache/images/figs/banners/70x40-crop-80-networkyness_compressed.jpg" alt="multi-scale models" width="70" height="40" />
						</span>						<span>
						multi-scale models						</span>
						
					</span>
				</div>
								<div class="dj-tab ">
					<span class="dj-tab-in">						
						
						<!--[if lte IE 7]>
						<table cellpadding="0" cellspacing="0" border="0"><tr>
													<td>
							<img src="/media/djmediatools/cache/images/figs/banners/70x40-crop-80-bloodsamples_compressed.jpg" alt="biomarker discovery" width="70" height="40" />
							</td>
												<td width="100%">
						biomarker discovery						</td>
						</tr></table>
						<![endif]-->
						
						<span>
							<img src="/media/djmediatools/cache/images/figs/banners/70x40-crop-80-bloodsamples_compressed.jpg" alt="biomarker discovery" width="70" height="40" />
						</span>						<span>
						biomarker discovery						</span>
						
					</span>
				</div>
								<div class="dj-tab ">
					<span class="dj-tab-in">						
						
						<!--[if lte IE 7]>
						<table cellpadding="0" cellspacing="0" border="0"><tr>
													<td>
							<img src="/media/djmediatools/cache/images/figs/banners/70x40-crop-80-flippedandstuff_compressed.jpg" alt="tumor evolution" width="70" height="40" />
							</td>
												<td width="100%">
						tumor evolution						</td>
						</tr></table>
						<![endif]-->
						
						<span>
							<img src="/media/djmediatools/cache/images/figs/banners/70x40-crop-80-flippedandstuff_compressed.jpg" alt="tumor evolution" width="70" height="40" />
						</span>						<span>
						tumor evolution						</span>
						
					</span>
				</div>
								<div class="dj-tab ">
					<span class="dj-tab-in">						
						
						<!--[if lte IE 7]>
						<table cellpadding="0" cellspacing="0" border="0"><tr>
													<td>
							<img src="/media/djmediatools/cache/images/figs/70x40-crop-80-psuedo2d_gel.jpg" alt="proteomics technology" width="70" height="40" />
							</td>
												<td width="100%">
						proteomics technology						</td>
						</tr></table>
						<![endif]-->
						
						<span>
							<img src="/media/djmediatools/cache/images/figs/70x40-crop-80-psuedo2d_gel.jpg" alt="proteomics technology" width="70" height="40" />
						</span>						<span>
						proteomics technology						</span>
						
					</span>
				</div>
								<div class="dj-tab ">
					<span class="dj-tab-in">						
						
						<!--[if lte IE 7]>
						<table cellpadding="0" cellspacing="0" border="0"><tr>
													<td>
							<img src="/media/djmediatools/cache/images/figs/banners/70x40-crop-80-proteowizard_psdeps_onpurple_compressed.jpg" alt="proteoWizard" width="70" height="40" />
							</td>
												<td width="100%">
						proteoWizard						</td>
						</tr></table>
						<![endif]-->
						
						<span>
							<img src="/media/djmediatools/cache/images/figs/banners/70x40-crop-80-proteowizard_psdeps_onpurple_compressed.jpg" alt="proteoWizard" width="70" height="40" />
						</span>						<span>
						proteoWizard						</span>
						
					</span>
				</div>
													<div class="dj-tab-indicator  dj-tab-indicator-right"></div>
							</div>
		</div>
		
		<div class="dj-loader"></div>
	</div>
</div>
</div>

<div style="clear: both"></div>		    </div>
		</div>
	</div>
	
			</div>				
		</div>
	</div>
</header>
			
<section id="jm-breadcrumbs-fontswitcher">
	<div class="container-fluid">
		<div class="row-fluid">
									<div class="span12">
	            <div id="jm-font-switcher">
	                <a href="/index.php" class="texttoggler" rel="smallview" title="small size"><img src="https://mallicklab.stanford.edu/templates/jm-exclusive-furniture/images/smaller.png" alt="Smaller" /></a>
	                <a href="/index.php" class="texttoggler" rel="normalview" title="normal size"><img src="https://mallicklab.stanford.edu/templates/jm-exclusive-furniture/images/default.png" alt="Default" /></a>
	                <a href="/index.php" class="texttoggler" rel="largeview" title="large size"><img src="https://mallicklab.stanford.edu/templates/jm-exclusive-furniture/images/larger.png" alt="Larger" /></a>
	            	<script type="text/javascript">
					//documenttextsizer.setup("shared_css_class_of_toggler_controls")
					documenttextsizer.setup("texttoggler")
					</script>
	            </div>
			</div>
					</div>
	</div>
</section>
			
			
<section id="jm-top2">
	<div class="container-fluid">
		<div id="jm-top2-in" class="horizontal">
			<div class="top2 count_3"><div class="row-fluid"><div class="top2-in span4"><div class="top2-bg">	<div class="jm-module ">
		<div  class="jm-module-in">
					    <div class="jm-module-content clearfix">
		    	

<div class="custom"  >
	<p class="font-module" style="font-weight: 300; font-size: 2.1em; line-height: 1em; margin: 0 0 10px;">overview</p>
<p>The Mallick lab focuses on translating multi-omic discovery into precision diagnostics. We use integrative, multi-omic approaches to model the processes that govern proteome dynamics and then use those models to discover cancer biomarkers and mechanisms.</p>
<p> </p></div>
		    </div>
		</div>
	</div>
	</div></div><div class="top2-in span3"><div class="top2-bg">	<div class="jm-module ">
		<div  class="jm-module-in">
					    <div class="jm-module-content clearfix">
		    	

<div class="custom"  >
	<p> </p>
<p><a href="http://canarycenter.stanford.edu" target="_blank"><img src="/images/figs/Canary.png" alt="Canary Center @ Stanford" width="200" style="border: 2px solid black; vertical-align: middle; margin: 5px;" /></a></p></div>
		    </div>
		</div>
	</div>
	</div></div><div class="top2-in span4"><div class="top2-bg">	<div class="jm-module ">
		<div  class="jm-module-in">
					    <div class="jm-module-content clearfix">
		    	

<div class="custom"  >
	<p class="font-module" style="font-weight: 300; font-size: 2.1em; line-height: 1em; margin: 0 0 10px;">news</p>
<p>check out our latest papers on</p>
<p>- <a href="http://www.nature.com/nbt/journal/v30/n10/full/nbt.2377.html" target="_blank">ProteoWizard</a> (Nature Biotech)</p>
<p>- <a href="http://www.pnas.org/content/early/2013/04/19/1218806110.abstract" target="_blank">Cell Squishyness &amp; Sliminess &amp; Metastatic Potential</a> (PNAS)</p>
<p>- <a href="http://dx.doi.org/10.1186/s13073-016-0305-0" target="_blank">Drug Resistance as Mediated by Epigenetics</a> (Genome Medicine)</p>
<p>- <a href="http://www.nature.com/nprot/journal/v10/n3/full/nprot.2015.015.html" target="_blank"> SWATH MS Libraries </a> (Nature Protocols)</p></div>
		    </div>
		</div>
	</div>
	</div></div></div></div>		</div>
	</div>
</section>
	
			
<section id="jm-main" class="scheme1 clr">
	<div class="container-fluid">
		<div class="row-fluid">
			<div id="jm-content" class="span12">
												<div id="jm-maincontent">
					<div id="system-message-container">
	</div>

					<div class="blog-featured" itemscope itemtype="https://schema.org/Blog">



</div>
				</div>
											</div>
								</div>
	</div>
</section>			
			<footer id="jm-footer" >
	<div class="container-fluid">
					<div class="footer-mod count_3"><div class="row-fluid"><div class="footer-mod-in span3"><div class="footer-mod-bg">	<div class="jm-module blank-ms">
		<div  class="jm-module-in">
						<div class="jm-title-wrap">
			<div class="jm-title-space">
		   		<h3 class="jm-title ">hiring</h3>
		   	</div>
		   	</div>
		   	
		   			    <div class="jm-module-content clearfix">
		    	

<div class="customblank-ms"  >
	<p>We're always on the lookout for nice people to join our group.  Right now we are particularly looking for researchers with expertise in cancer biology and researchers with experience in integrated omics or computational proteomics.</p></div>
		    </div>
		</div>
	</div>
	</div></div><div class="footer-mod-in span3"><div class="footer-mod-bg">	<div class="jm-module blank-ms">
		<div  class="jm-module-in">
						<div class="jm-title-wrap">
			<div class="jm-title-space">
		   		<h3 class="jm-title ">contact us</h3>
		   	</div>
		   	</div>
		   	
		   			    <div class="jm-module-content clearfix">
		    	

<div class="customblank-ms"  >
	<div class="clearfix" style="padding: 4px 0 10px;">
<div class="jm-custom-img"><img src="/images/modules/home.png" alt="Home" /></div>
<div class="jm-custom-desc">3155 Porter Drive<br />Palo Alto, CA 94304</div>
</div>
<div class="clearfix" style="padding: 0 0 10px;">
<div class="jm-custom-img"><img src="/images/modules/email.png" alt="Phone" /></div>
<div class="jm-custom-desc"><strong>email</strong></div>
<div class="jm-custom-desc">paragm<small> [AT] </small>stanford<small> [DOT] </small>edu</div>
</div>
<div class="clearfix">
<div class="jm-custom-img"><img src="/images/modules/direction.png" alt="Email" /></div>
<div class="jm-custom-desc"><strong>directions</strong><br /> Check out how to <a href="http://goo.gl/maps/Fns27">find us</a></div>
</div></div>
		    </div>
		</div>
	</div>
	</div></div><div class="footer-mod-in span3"><div class="footer-mod-bg">	<div class="jm-module jm-heart">
		<div  class="jm-module-in">
						<div class="jm-title-wrap">
			<div class="jm-title-space">
		   		<h3 class="jm-title ">donate</h3>
		   	</div>
		   	</div>
		   	
		   			    <div class="jm-module-content clearfix">
		    	

<div class="customjm-heart"  >
	<p>If you would like to support the efforts of the Mallick Lab or of ProteoWizard, you can donate by clicking <a title="Donate to the Mallick Lab" href="http:/giving.stanford.edu/goto/mallickgift" target="_blank" rel="noopener noreferrer"><strong>HERE</strong></a>.  Thank you so much for your support!</p></div>
		    </div>
		</div>
	</div>
	</div></div></div></div>			</div>
	<div class="container-fluid jm-footer-details">
		<div class="jm-footer-details-in">	
						<div id="jm-copyrights">
				

<div class="custom"  >
	<p style="margin: 0;">Copyright Mallick Lab. All rights reserved.</p></div>

			</div>
						<div id="jm-poweredby">
				&nbsp;
			</div>
					</div>
	</div>
</footer>
<p id="jm-back-top" style="display: block;"><a href="#top"><span></span>&nbsp;</a></p>
		</div>
	</body>
</html>